// AVLSet.hpp
//
// ICS 46 Winter 2-118
// Project #4: Set the Controls for the Heart of the Sun
//
// An AVLSet is an implementation of a Set that is an AVL tree, which uses
// the algorithms we discussed in lecture to maintain balance every time a
// new element is added to the set.
//
// You are not permitted to use the containers in the C++ Standard Library
// (such as std::set, std::map, or std::vector) to store the information
// in your data structure.  Instead, you'll need to implement your AVL tree
// using your own dynamically-allocated nodes, with pointers connecting them,
// and with your own balancing algorithms used.

#ifndef AVLSET_HPP
#define AVLSET_HPP

#include <functional>
#include "Set.hpp"
//#include <algorithm>
#include <iostream>



template <typename T>
class AVLSet : public Set<T>
{
public:
    // Initializes an AVLSet to be empty.
    AVLSet();

    // Cleans up the AVLSet so that it leaks no memory.
    virtual ~AVLSet() noexcept;

    // Initializes a new AVLSet to be a copy of an existing one.
    AVLSet(const AVLSet& s);

    // Initializes a new AVLSet whose contents are moved from an
    // expiring one.
    AVLSet(AVLSet&& s) noexcept;

    // Assigns an existing AVLSet into another.
    AVLSet& operator=(const AVLSet& s);

    // Assigns an expiring AVLSet into another.
    AVLSet& operator=(AVLSet&& s) noexcept;


    // isImplemented() should be modified to return true if you've
    // decided to implement an AVLSet, false otherwise.
    virtual bool isImplemented() const noexcept override;


    // add() adds an element to the set.  If the element is already in the set,
    // this function has no effect.  This function always runs in O(log n) time
    // when there are n elements in the AVL tree.
    virtual void add(const T& element) override;


    // contains() returns true if the given element is already in the set,
    // false otherwise.  This function always runs in O(log n) time when
    // there are n elements in the AVL tree.
    virtual bool contains(const T& element) const override;


    // size() returns the number of elements in the set.
    virtual unsigned int size() const noexcept override;


    // height() returns the height of the AVL tree.
    int height() const;


    // preorder() visits all of the elements in the AVL tree in preorder,
    // calling the given "visit" function and passing it each element.
    void preorder(std::function<void(const T&)> visit) const;


    // inorder() visits all of the elements in the AVL tree in order
    // calling the given "visit" function and passing it each element.
    void inorder(std::function<void(const T&)> visit) const;


    // postorder() visits all of the elements in the AVL tree in postorder
    // calling the given "visit" function and passing it each element.
    void postorder(std::function<void(const T&)> visit) const;



private:

    struct
    Node{
        Node* Left = nullptr;
        Node* Right = nullptr;
        T key;
        int h = -1;
    };
    Node* root;
    unsigned int tree_size;
    void delete_tree( Node* x); //recursively deletes tree given the tree root
    void copy(Node* x, Node* y); //recursively copies tree given trees nodes
    void pre(Node* x, std::function<void(const T&)>visit) const;//helper function for preorder
    void post(Node* x, std::function<void(const T&)>visit) const;
    void in(Node* x, std::function<void(const T&)>visit) const;
    bool exists(Node* x,const T& element); // checks if element exists given a tree root
    Node* add_and_balance(Node* x, const T& element);//insert a node  given an tree root and element and balance the tree
    Node* balance_tree(Node* root); // balances a tree given its root and returns the new root
    Node* Left_rotate( Node* x);
    Node* Right_rotate( Node* x);
    int  find_height(Node* x); // fixes and returns the hieght of tree given its root


};
template <typename T>
AVLSet<T>::AVLSet()
{
    root = nullptr;
    tree_size = -1;
}
template <typename T>
void AVLSet<T>::copy(Node* x, Node* y)
{   
    if(x==nullptr ||y==nullptr)
    {
        return;
    }
    while(y != nullptr)
    {
        if(x == nullptr)
        {
            return;//x = new Node();
        }
        x->key = y->key;
        x->Right = y->Right;
        x->Left = y->Left;
        x->h = y->h;
        if(y->Left != nullptr)
        {
            copy(x->Left, y->Left);
        }
        if(y->Right != nullptr)
        {
            copy(x->Right, y->Right);
        }
    }
}

template <typename T>
AVLSet<T>::AVLSet(const AVLSet& s)
{
    //delete_tree (root);
    root = nullptr;
    Node* iterator = s.root;
   // root = s.root;
    copy(root, iterator);
    tree_size = s.tree_size;

}

template <typename T>
AVLSet<T>::~AVLSet() noexcept
{   
    if(root != nullptr)
    {
        delete_tree(root);
        root = nullptr;
        tree_size = -1;
    }
    delete root;
}
template <typename T>
AVLSet<T>::AVLSet(AVLSet&& s) noexcept
{
 /*   Node* temp = root;
    int temp_s = tree_size;
    root = s.root;
    tree_size = s.tree_size;

    s.root = temp;
    s.tree_size = temp_s;
    if(s.root == nullptr)
    {
        root = nullptr;
        return;
    }*/

   //std::swap(root,s.root);
   root= s.root;

}
template<typename T>
int AVLSet<T>::find_height(Node* x)
{
    int z;
    int y;
    if(x->Right == nullptr)
    {
        y = -1;
    } 
    else
    {
        y= x->Right->h;
    }

    if(x->Left == nullptr)
    {
        z= -1;
    }
    else
    {
        z=x->Left->h;
    }
    x->h = std::max(z,y)+1;

    return x->h; 
}
template<typename T>
typename AVLSet<T>::Node* AVLSet<T>::balance_tree(Node* x)
{
    int root_h = find_height(x);
    int diff = find_height(x->Right) -find_height(x->Left) ;

    if(diff == -2)
    {
        if(find_height(x->Left->Right) - find_height(x->Left->Left) > -1)
        {
            x->Left = Left_rotate(x->Left);
        }
        return Right_rotate(x);
    }

    else if(diff == 2)
    {
        if(find_height(x->Right->Right) - find_height(x->Right->Left) < -1)
        {
            x->Right = Right_rotate(x->Right);
        }
        return Left_rotate(x);
    }
    root_h = -1;
    return x; 
}
template <typename T>
typename AVLSet<T>::Node* AVLSet<T>::Left_rotate( Node* x)
{
    Node* temp = x->Right;
    x->Right = temp->Left;
    temp->Left = x;
    int hi = find_height(temp);
    int bye = find_height(x);
    hi = -1;
    bye =-1;
    return temp;
}

template <typename T>
 typename AVLSet<T>::Node* AVLSet<T>::Right_rotate( Node* x)
{
    Node* temp = x->Left;
    x->Left = temp->Right;
    temp->Right = x;
    int hi = find_height(temp);
    int bye = find_height(x);
    hi = -1;
    bye =-1;
    return temp;
}
template <typename T>
 typename AVLSet<T>::Node* AVLSet<T>::add_and_balance(Node* x, const T& element)
{
    if(x == nullptr)
    {
        return nullptr;
    }
    if(x->Right == nullptr && element > x->key)
   {
    Node* xg = new Node;
    xg->Right = nullptr;
    xg->Left= nullptr;
    xg->key = element;
    xg->h = -1;
    x->Right = xg;
    return xg;
   } 

   if(x->Left == nullptr && element < x->key)
   {
   Node* xg = new Node;
    xg->Left = nullptr;
    xg->Right= nullptr;
    xg->key = element;
    xg->h = -1;
    x->Left = xg;
    return xg;
   } 
   else if(element > x->key && x->Right != nullptr)
   {
    x->Right = add_and_balance(x->Right, element);
   }
   else if(x->Left != nullptr)
   {
    x->Left = add_and_balance(x->Left, element);
   }
   x = balance_tree(x);
   return x; // new root of balanced tree
}



template <typename T>
void AVLSet<T>::delete_tree(Node* x)
{
/*    if( x == nullptr )
    {
        return;
    }
    else
    {

        delete_tree(x->Right);
        delete_tree(x->Left);
        delete x;
    }*/
    if(x !=nullptr)
    {
    
    
//{
    delete_tree(x->Right);
//}
//{
    delete_tree(x->Left);
//}


    delete x;
}

/*Node* iterator = x;
Node* t = iterator;
while(iterator != nullptr)
{   t= iterator->Right;
    delete iterator;
    iterator = t;
}
iterator =x;
t = iterator;

while(iterator != nullptr)
{
    t= iterator->Left;
    delete iterator;
    iterator = t;   
}*/

}




template <typename T>
bool AVLSet<T>::exists(Node* x, const T& element)
{
    if(x == nullptr)
    {
        return false;
    }
    bool flag = false;
    if(element < x->key)
    {
      flag = exists(x->Left , element);   
    }
    else if(element > x->key)
    {
      flag = exists(x->Right , element);   
    }
    else
    {
        flag = true;
    }
    return flag;
}

template <typename T>
AVLSet<T>& AVLSet<T>::operator=(const AVLSet& s)
{
    delete_tree(root);
    copy(root,s.root);
    return *this;
}


template <typename T>
AVLSet<T>& AVLSet<T>::operator=(AVLSet&& s) noexcept
{
        std::swap(root,s.root);

/*    delete_tree(root);
    root = s.root;
    tree_size = s.tree_size;*/
    return *this;
}


template <typename T>
bool AVLSet<T>::isImplemented() const noexcept
{
    return true;
}


template <typename T>
void AVLSet<T>::add(const T& element)
{
    if(contains(element) == true)
    {
        return;
    }
    root = add_and_balance(root, element);
}


template <typename T>
bool AVLSet<T>::contains(const T& element) const
{
    return false;
}


template <typename T>
unsigned int AVLSet<T>::size() const noexcept
{
    return tree_size;
}


template <typename T>
int AVLSet<T>::height() const
{
    if(root == nullptr)
    {
        return -1;
    }
    return std::max(root->Left->h , root->Right->h); // or return root->h;
}

template <typename T>
void AVLSet<T>::pre(Node* x, std::function<void(const T&)>visit) const
{

    if(x == nullptr)
    {
        return;
    }
    visit(x->key);
    pre(x->Left, visit); 
    pre(x->Right, visit);
}

template <typename T>
void AVLSet<T>::preorder(std::function<void(const T&)> visit) const
{
     pre(root,visit);
}

template <typename T>
void AVLSet<T>::in(Node* x, std::function<void(const T&)>visit) const
{

    if(x == nullptr)
    {
        return;
    }
   
    pre(x->Left, visit);
    visit(x->key);
    pre(x->Right, visit); 

}

template <typename T>
void AVLSet<T>::inorder(std::function<void(const T&)> visit) const
{
    in(root, visit); 
}

template <typename T>
void AVLSet<T>::post(Node* x, std::function<void(const T&)>visit) const
{

    if(x == nullptr)
    {
        return;
    }
   
    pre(x->Left, visit);
    pre(x->Right, visit); 
    visit(x->key);

}

template <typename T>
void AVLSet<T>::postorder(std::function<void(const T&)> visit) const
{
    post(root, visit); 
}



#endif // AVLSET_HPP

