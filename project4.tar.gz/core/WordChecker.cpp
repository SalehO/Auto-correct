// WordChecker.cpp
//
// ICS 46 Winter 2018
// Project #4: Set the Controls for the Heart of the Sun
//
// Replace and/or augment the implementations below as needed to meet
// the requirements.

#include "WordChecker.hpp"
#include "AVLSet.hpp"
#include "HashSet.hpp"
#include <iostream>
#include <string>
#include <vector>

using namespace std;


WordChecker::WordChecker(const Set<string>& words)
    : words{words}
{
}


bool WordChecker::wordExists(const string& word) const
{
     bool flag = false;
      if(words.contains(word) == true)
      {
      	flag = true;
      }
      else
      {
      	flag = false;
      }
     return flag;
}


const bool already_exists(vector<string> v, const string s)//checks if the word was already suggested so it doesnt suggest the same word for a string twice
{
	if(find(v.begin(),v.end(), s) == v.end())
	{
		return false;
	}
	else
	{
		return true;
	}
}

std::vector<std::string> WordChecker::findSuggestions(const std::string& word) const
{
	string chars ="ABCDEFGHIJKLMNOPQRSTUVWXYZ " ;
	vector<string> Strings; // to hold the suggested strings
	string test;// for temoporary use
        for (int i= 0; i < word.size(); i++) 
        {
            for (int y = 0; y< chars.size(); y++)
            {
            	test = word;
            	if(test[i] != chars[i])
            	{
            		test[i] = chars[y];	
            	}

                if (already_exists(Strings,test)== false && wordExists(test) )
                {
                   Strings.push_back(test);
                }
            }
        }
        for (int i =0; i < word.size(); i++)
        {
            for (int x = 0; x < chars.size(); x++)
            {
            	test = word;
                test.insert(i, chars.substr(x,1));
                if (already_exists(Strings,test)==false && wordExists(test))
                {
                    Strings.push_back(test);
                }
            }
        }
        for (int i = 0; i < word.size(); i++)
        {
        	test = word;
            test = test.erase(i,1);
             if (already_exists(Strings,test)==false && wordExists(test) )
             {
                Strings.push_back(test);
             }
        }
        for (int x= 0; x < word.size()-1 ; x++) //suptract 1 from size to no swap with an empty character
        {
        	test = word;
            swap(test[x],test[x+1]);
            if (already_exists(Strings,test)==false && wordExists(test))
            {
                Strings.push_back(test);
            }
        }
        for (int i = 0; i < word.size() - 1; i++) //checks for suggestions if space is added between substrings
        {
        	test = word;
        	string first_half;
            string second_half;
            first_half = test.substr(0,i);
			second_half =  test.substr(i,test.size());        
            if (already_exists(Strings,first_half)==false && wordExists(first_half) && already_exists(Strings,second_half)==false && wordExists(second_half))
            {
                Strings.push_back(test.insert(i," "));
            }
        }
            return Strings; //vector of suggested string
}