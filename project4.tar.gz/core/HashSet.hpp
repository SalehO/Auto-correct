// HashSet.hpp
//
// ICS 46 Winter 2018
// Project #4: Set the Controls for the Heart of the Sun
//
// A HashSet is an implementation of a Set that is a separately-chained
// hash table, implemented as a dynamically-allocated array of linked
// lists.  At any given time, the HashSet has a "size" indicating
// how many elements are stored within it, along with a "capacity"
// indicating the size of the array.
//
// As elements are added to the HashSet and the proportion of the HashSet's
// size to its capacity exceeds 0.8 (i.e., there are more than 80% as many
// elements as there are array Nodes), the HashSet should be resized so
// that it is twice as large as it was before.
//
// You are not permitted to use the containers in the C++ Standard Library
// (such as std::set, std::map, or std::vector) to store the information
// in your data structure.  Instead, you'll need to use a dynamically-
// allocated array and your own linked list implemenation; the linked list
// doesn't have to be its own class, though you can do that, if you'd like.

#ifndef HASHSET_HPP
#define HASHSET_HPP

#include <functional>
#include "Set.hpp"
#include <cmath>



template <typename T>
class HashSet : public Set<T>
{
public:
    // The default capacity of the HashSet before anything has been
    // added to it.
    static constexpr unsigned int DEFAULT_CAPACITY = 10;

    // A HashFunction is a function that takes a reference to a const T
    // and returns an unsigned int.
    typedef std::function<unsigned int(const T&)> HashFunction;

public:
    // Initializes a HashSet to be empty, so that it will use the given
    // hash function whenever it needs to hash an element.
    HashSet(HashFunction hashFunction);

    // Cleans up the HashSet so that it leaks no memory.
    virtual ~HashSet() noexcept;

    // Initializes a new HashSet to be a copy of an existing one.
    HashSet(const HashSet& s);

    // Initializes a new HashSet whose contents are moved from an
    // expiring one.
    HashSet(HashSet&& s) noexcept;

    // Assigns an existing HashSet into another.
    HashSet& operator=(const HashSet& s);

    // Assigns an expiring HashSet into another.
    HashSet& operator=(HashSet&& s) noexcept;


    // isImplemented() should be modified to return true if you've
    // decided to implement a HashSet, false otherwise.
    virtual bool isImplemented() const noexcept override;


    // add() adds an element to the set.  If the element is already in the set,
    // this function has no effect.  This function triggers a resizing of the
    // array when the ratio of size to capacity would exceed 0.8.  In the case
    // where the array is resized, this function runs in linear time (with
    // respect to the number of elements, assuming a good hash function);
    // otherwise, it runs in constant time (again, assuming a good hash
    // function).
    virtual void add(const T& element) override;


    // contains() returns true if the given element is already in the set,
    // false otherwise.  This function runs in constant time (with respect
    // to the number of elements, assuming a good hash function).
    virtual bool contains(const T& element) const override;


    // size() returns the number of elements in the set.
    virtual unsigned int size() const noexcept override;


    // elementsAtIndex() returns the number of elements that hashed to a
    // particular index in the array.  If the index is out of the boundaries
    // of the array, this function returns 0.
    unsigned int elementsAtIndex(unsigned int index) const;


    // isElementAtIndex() returns true if the given element hashed to a
    // particular index in the array, false otherwise.  If the index is
    // out of the boundaries of the array, this functions returns 0.
    bool isElementAtIndex(const T& element, unsigned int index) const;
    void ADD_VALUE(const T & value);


private:
    HashFunction hashFunction;
    struct Node
    {
        T key;
        Node *plus = nullptr;
    };
    int max=0; // capacity
    int table_size=0;//size
    Node** current;
};



template <typename T>
HashSet<T>::HashSet(HashFunction hashFunction)
    : hashFunction{hashFunction}
{
    max= DEFAULT_CAPACITY;
    current = new Node*[max];
    table_size = 0; //create an array of pointers of nodes/Nodes
}


template <typename T>
HashSet<T>::~HashSet() noexcept
{
    int x =0;
    while(x < table_size-1)
    {
        Node* temp = current[x];
        Node* t2 = temp;
        if(current[x] != nullptr)
        {
            while(temp != nullptr)
            {
                t2 = temp->plus;
                delete temp;
                temp = t2;
            }
        }
        delete current[x];
        ++x;
    }
   // delete current[x];
}


template <typename T>
HashSet<T>::HashSet(const HashSet& s)
    : hashFunction{nullptr}
{
      int x =0;
    while(x < table_size-1)
    {
        Node* temp = current[x];
        Node* t2 = temp;
        if(current[x] != nullptr)
        {
            while(temp != nullptr)
            {
                t2 = temp->plus;
                delete temp;
                temp = t2;
            }
        }
        delete current[x];
        ++x;
    }
   // delete cuurent[x];

    for (int i = 0; i<= s.table_size-1; i++)
    {
        current[i] = s.current[i];
    }

}


template <typename T>
HashSet<T>::HashSet(HashSet&& s) noexcept
    : hashFunction{nullptr}
{
   // HashFunction = h;
 /*   Node** c;
   //h = hashFunction;
    c= current;

    hashFunction = s.hashFunction;
    current = s.current;
    //s.hashFunction = h;
    s.current = c;*/
    std::swap(s.current,current);
}


template <typename T>
HashSet<T>& HashSet<T>::operator=(const HashSet& s)
{
    int x =0;
    while(x < table_size-1)
    {
        Node* temp = current[x];
        Node* t2 = temp;
        if(current[x] != nullptr)
        {
            while(temp != nullptr)
            {
                t2 = temp->plus;
                delete temp;
                temp = t2;
            }
        }
        delete current[x];
        ++x;
    }
    current = s.current;
    hashFunction = s.hashFunction;
    return *this;
}


template <typename T>
HashSet<T>& HashSet<T>::operator=(HashSet&& s) noexcept
{
/*    if( this != &s)
    {
        hashFunction =s.hashFunction;
        current= s.current;
    }*/
    std::swap(s.current, current);
    return *this;
}


template <typename T>
bool HashSet<T>::isImplemented() const noexcept
{
    return true;
}

template <typename T>
void HashSet<T>::ADD_VALUE(const T& value)
{
    Node* temp;
    int x = hashFunction(value) % max ;
  // Node* ad = new Node;
   // ad->key= value;
    temp = current[x];
    if(temp != nullptr)
    {
/*        while( temp->plus != nullptr) // go to the end of the liked list if not empty
        {
            temp = temp->plus;
        }

        temp->plus = new Node;
        temp->key= value;*/////////////////////////
        Node* n = new Node;
        n->key = value;
        n->plus = current[hashFunction(value)/max];
        current[hashFunction(value)/max] = n;
    }
    else 
    {
        current[x] = new Node;
        current[x]->key=value;
        //current[x]->plus = nullptr;
        table_size++; //////////////////////////
    }
}

template <typename T>
void HashSet<T>::add(const T& element)
{
    Node** temp_current;
   // current = new Node*[max];
    int temp_max;
    temp_max = max;
    temp_current = current;
    int  i = 0;
    //int j = 0;
    //Node* temp;

    if((table_size / max) < 0.8)
    {
   /*     Node* n = new Node;
        n->key = element;
        n->plus = current[hashFunction(element)/max];
        current[hashFunction(element)/max] = n;*/
        

        ADD_VALUE(element);
/*    Node* temp;//add element to list
    int x = hashFunction(element) % max;
    temp = current[x];
    if( temp != nullptr)
    {
        while( temp != nullptr)
        {
            temp = temp->plus;
        }
        temp = new Node{element};
    }
    else if(temp == nullptr)
    {
        current[x] = new Node{element};
    }*/
    }
    else
    {
        max = 2*max;
        delete[] current;
        current = new Node*[max]; //resize
        ADD_VALUE(element);

        while(i < table_size)
        {
            if(temp_current[i] != nullptr)
            {
                Node* iterate = temp_current[i];
                while(iterate != nullptr)
                {
                    ADD_VALUE(iterate->key);
                    iterate = iterate->plus; 
                }
            }
            ++i;
        }
    }
    //delete[] temp_current;
}
           // table_size++;




template <typename T>
bool HashSet<T>::contains(const T& element) const
{
    for(int x=0; x<= table_size; x++)
    {
        Node* iterate = current[x];
        if(iterate != nullptr)
        {
            if(iterate-> key == element)
            {
                return true;
            }
            else
            {
                iterate = iterate->plus; //move pointer to next and check
                if(iterate-> key == element)
                {
                    return true;
                }
            }
        }
    }

    return false;
}


template <typename T>
unsigned int HashSet<T>::size() const noexcept
{
    return table_size;
}


template <typename T>
unsigned int HashSet<T>::elementsAtIndex(unsigned int index) const
{
    if(index > max || current[index+1] == nullptr)
    {
        return 0;
    }
    else
    {
        int count = 0;
        Node* iterator = current[index+1];
        while(iterator->plus != nullptr)
        {      
            iterator = iterator->plus;
            count++;
        }
        return count+1;
    }
}


template <typename T>
bool HashSet<T>::isElementAtIndex(const T& element, unsigned int index) const
{
    if(index > max)
    {
        return 0;
    }
    else
    {
        //int count = 0;
        Node* iterator = current[index+1];
        while(iterator != nullptr)
        {   
        if(iterator->key == element)
        {
            return true;
        }   
            iterator = iterator->plus;
            //count++;
        }
       // return count+1;
    }   
    return false;
}



#endif // HASHSET_HPP

